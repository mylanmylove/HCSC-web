$.get('sources/blog/blog4/title.txt', function(data) {
  $('.title').text(data)
}, 'text');

$.get('sources/blog/blog4/content.txt', function(data) {
  var new_data = '';
  var i = 0;
  while(i < 200 || data[i] != '.')
  {
    new_data += data[i];
    i++;
  }
 
  new_data += '.';

  $('.summary').text(new_data)
}, 'text');

$.get('sources/blog/blog4/content.txt', function(data) {
  $('.content').text(data)
}, 'text');




// Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position


$(window).bind('mousewheel', function(event) {
  
  // When the user scrolls the page, execute myFunction
  window.onscroll = function() {myFunction()};

  // Get the navbar
  var navbar = document.getElementById("navbar");

  // Get the offset position of the navbar
  var sticky = 30;

  function myFunction() {
    if (window.pageYOffset >= sticky && ext)
    {
      navbar.classList.add("sticky");
      setTimeout(function(){
        $('.nav').removeClass('sticky');
        ext = false;
      },3500);
    }
    


    if (window.pageYOffset < sticky)
    {
      ext = true;
      $('.nav').removeClass('sticky');
    }

    if (event.originalEvent.wheelDelta >= 0 && window.pageYOffset >= sticky) {
      navbar.classList.add("sticky");
      setTimeout(function(){
        $('.nav').removeClass('sticky');
      },3500);
    }
  }
  
  if (event.originalEvent.wheelDelta >= 0) {
      console.log('Scroll up');
  }
  else {
      console.log('Scroll down');
  }
});



$(document).ready(function() {
    $('#menu').click(function() {
      if (document.getElementById('menu-list').style.visibility === "visible")
      {
        document.getElementById('menu-list').style.visibility = "hidden";
      }
      else{
        document.getElementById('menu-list').style.visibility = "visible";
      }
    });
});

